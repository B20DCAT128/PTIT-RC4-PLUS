import sys
import subprocess

def text_to_key(text):
    return [ord(char) % 256 for char in text]

def ksa_plus(key, iv, N):
    S = list(range(N))
    j = 0

    for i in range(N):
        j = (j + S[i] + key[i % len(key)]) % N
        S[i], S[j] = S[j], S[i]

    for i in range(N // 2 - 1, -1, -1):
        j = ((j + S[i]) % N + (key[i % len(key)] + iv[i % len(iv)]) % N) % N
        S[i], S[j] = S[j], S[i]
    for i in range(N // 2, N):
        j = ((j + S[i]) % N + (key[i % len(key)] + iv[i % len(iv)]) % N) % N
        S[i], S[j] = S[j], S[i]

    for y in range(N):
        if y % 2 == 0:
            i = y // 2
        else:
            i = N - (y + 1) // 2
        j = (j + S[i] + key[i % len(key)]) % N
        S[i], S[j] = S[j], S[i]

    return S

def prga_plus(S, length, N):
    i = 0
    j = 0
    keystream = []
    for _ in range(length):
        i = (i + 1) % N
        j = (j + S[i]) % N
        S[i], S[j] = S[j], S[i]
        t1 = (S[i] + S[j]) % N
        t2 = ((S[((i >> 3) ^ (j << 5)) % N] + S[((i << 5) ^ (j >> 3)) % N]) % N) ^ 0xAA
        t3 = (j + S[j]) % N
        z = (S[t1] + S[t2]) ^ S[t3]
        keystream.append(z % N)
    return keystream

def process_data(action, key1, key2, data):
    N = 256
    S = ksa_plus(key1, key2, N)
    keystream = prga_plus(S, len(data), N)
    result = bytes([c ^ k for c, k in zip(data, keystream)])
    return result

def save_to_file(filename, data):
    with open(filename, 'w') as f:
        f.write(data)

if __name__ == "__main__":
    try:
        if len(sys.argv) < 4:
            print("Usage: python3 rc4_plus.py <encode|decode> <key> <iv> [<data>]")
            sys.exit(1)

        action = sys.argv[1]
        key1 = text_to_key(sys.argv[2])
        key2 = text_to_key(sys.argv[3])

        if action == "encode":
            if len(sys.argv) < 5:
                print("Usage: python3 rc4_plus.py encode <key> <iv> <data>")
                sys.exit(1)
            data = bytes(sys.argv[4], 'utf-8')
            encoded_data = process_data(action, key1, key2, data)
            encoded_hex = encoded_data.hex()
            save_to_file("ciphertext.hex", encoded_hex)
            print("Data encoded and saved to 'ciphertext.hex'")
        
        elif action == "decode":
            with open("ciphertext.hex", 'r') as f:
                encoded_hex = f.read().strip()
            encoded_data = bytes.fromhex(encoded_hex)
            decoded_data = process_data(action, key1, key2, encoded_data)
            print("Decoded data:", decoded_data.decode('utf-8'))
            
            subprocess.run(["cat", "/home/check.txt"], check=True)
        
        else:
            raise ValueError("Invalid action! Use 'encode' or 'decode'.")

    except Exception as e:
        if str(e) == "Invalid action! Use 'encode' or 'decode'.":
            print("Please use a valid action: 'encode' or 'decode'.")
        else:
            print("Key hoac IV khong dung")

