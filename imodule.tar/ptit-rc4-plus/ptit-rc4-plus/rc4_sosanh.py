import os
import time
from prettytable import PrettyTable

def ksa(key, N=256):
    S = list(range(N))
    key_len = len(key)
    j = 0
    for i in range(N):
        j = (j + S[i] + key[i % key_len]) % N
        S[i], S[j] = S[j], S[i]
    return S

def prga(S, data_len, N=256):
    i = 0
    j = 0
    keystream = []
    for _ in range(data_len):
        i = (i + 1) % N
        j = (j + S[i]) % N
        S[i], S[j] = S[j], S[i]
        K = S[(S[i] + S[j]) % N]
        keystream.append(K)
    return keystream

def rc4_encrypt_decrypt(key, data):
    N = 256
    S = ksa(key, N)
    keystream = prga(S, len(data), N)
    return bytes([c ^ k for c, k in zip(data, keystream)])

def ksa_plus(key, iv, N):
    S = list(range(N))
    key_len = len(key)
    iv_len = len(iv)
    j = 0

    for i in range(N):
        j = (j + S[i] + key[i % key_len]) % N
        S[i], S[j] = S[j], S[i]
    
    iv_extended = [(key[i % key_len] + iv[i % iv_len]) % N for i in range(N)]
    for i in range(N):
        j = (j + S[i] + iv_extended[i]) % N
        S[i], S[j] = S[j], S[i]
    
    j = 0
    for y in range(N):
        i = y // 2 if y % 2 == 0 else N - (y + 1) // 2
        j = (j + S[i] + key[i % key_len]) % N
        S[i], S[j] = S[j], S[i]
    return S

def prga_plus(S, length, N):
    i = 0
    j = 0
    keystream = []
    for _ in range(length):
        i = (i + 1) % N
        j = (j + S[i]) % N
        S[i], S[j] = S[j], S[i]
        t1 = (S[i] + S[j]) % N
        t2 = ((S[((i >> 3) ^ (j << 5)) % N] + S[((i << 5) ^ (j >> 3)) % N]) % N) ^ 0xAA
        t3 = (j + S[j]) % N
        z = (S[t1] + S[t2]) ^ S[t3]
        keystream.append(z % N)
    return keystream

def rc4_plus_encrypt_decrypt(key, iv, data):
    N = 256
    S = ksa_plus(key, iv, N)
    keystream = prga_plus(S, len(data), N)
    return bytes([c ^ k for c, k in zip(data, keystream)])

def compare_rc4_rc4plus():
    key = os.urandom(32)
    iv = os.urandom(32)
    
    sizes = [0.05 * 1024* 1024, 1 * 1024 * 1024, 3 * 1024 * 1024, 5 * 1024 * 1024, 10 * 1024 * 1024]
    data_samples = [os.urandom(int(size)) for size in sizes]
    
    table = PrettyTable()
    table.field_names = ["Data Size (MB)", "RC4 (s)", "RC4+ (s)"]
    
    for index,(size, data) in enumerate(zip(sizes, data_samples)):
        data_size_mb = size / (1024 * 1024)
        start_time = time.time()
        rc4_encrypt_decrypt(key, data)
        rc4_encrypt_time = time.time() - start_time
        
        start_time = time.time()
        rc4_plus_encrypt_decrypt(key, iv, data)
        rc4plus_encrypt_time = time.time() - start_time

        if index != 0:
            table.add_row([
                f"{data_size_mb:.1f}",
                f"{rc4_encrypt_time:.6f}",
                f"{rc4plus_encrypt_time:.6f}"
            ])
    
    print(table)

if __name__ == "__main__":
    compare_rc4_rc4plus()

